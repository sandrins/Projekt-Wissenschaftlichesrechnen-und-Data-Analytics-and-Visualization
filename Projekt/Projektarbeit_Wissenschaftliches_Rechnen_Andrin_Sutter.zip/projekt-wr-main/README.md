Hallo 

Ich bin das README-File von Andrin Sutter zur Projektarbeit im Fach Wissenschaftliches Rechnen. Ich erkläre Ihnen kurz, wie Sie alle relevanten Daten von GitLab Ost herunterladen und wie Sie die Projektarbeit richtig starten.

Die gesamte Projektarbeit befindet sich in diesem Git-Repository. Das Repository können Sie entweder als ZIP-Datei herunterladen oder in einen Ordner auf Ihrem Rechner klonen.

Im Ordner "Daten_Projektarbeit" befinden sich alle notwendigen Bilder und Rohdaten für das Projekt. An diesem Ordner dürfen keine Änderungen vorgenommen werden. Dasselbe gilt für die gesamte Ordnerstruktur – diese soll so belassen werden, sonst werden Links gebrochen, und die Projektarbeit funktioniert nicht ordnungsgemäss.

Um die Projektarbeit auszuführen, muss das Jupyter-Notebook "Projektarbeit_Wissenschaftliches_Rechnen.ipynb" geöffnet werden. Sobald sich das Notebook geöffnet hat, muss der Knopf "Run All" (Deutsch: Alles Ausführen) gedrückt werden. Dadurch werden alle Code- und Markdown-Blöcke von oben nach unten ausgeführt. Somit müssen Sie nicht jeden einzelnen Codeblock manuell ausführen, und so sollten Fehler vermieden werden.

Ich wünsche viel Spass beim Erkunden der Projektarbeit von Andrin Sutter zum Thema Formel 1.

Freundliche Grüsse

Das README-File

*Informiert im Auftrag von Andrin Sutter*